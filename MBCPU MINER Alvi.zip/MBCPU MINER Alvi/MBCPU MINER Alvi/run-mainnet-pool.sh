./cpuminer -a power2b -o stratum+tcp://mbc-asia.skypool.co:8003 -u Be2jfvMk5fsgo6D43ZzkFqq2NTdgKjguay -p -t2
